#include <iostream>
#include <fstream>
#include <vector>
#include <cstdio>
#include <argparse/argparse.hpp>

// Forward declarations
void print_raw_dump(const std::string& filepath, std::size_t skip, std::size_t length, bool no_squeezing);
void print_normal_dump(const std::string& filepath);

int main(int argc, char* argv[]) {
    argparse::ArgumentParser program("akasha_dump", "1.0.0");
    program.add_description("Binary file analyzer with hexdump support");

    //AQUI
    program.add_argument("subcommand")
        .nargs(argparse::nargs_pattern::optional)
        .help("Subcommand: raw, canonical, etc.");
    
    program.add_argument("file")
        .nargs(argparse::nargs_pattern::optional)
        .help("Path to the binary file to inspect");
    
    program.add_argument("-n", "--length")
        .scan<'d', std::size_t>()
        .default_value(std::size_t(0))
        .help("Interpret only N bytes of input (0 = unlimited)");
    
    program.add_argument("-s", "--skip")
        .scan<'d', std::size_t>()
        .default_value(std::size_t(0))
        .help("Skip N bytes from the beginning");
    
    program.add_argument("--no-squeezing")
        .default_value(false)
        .implicit_value(true)
        .help("Show identical lines (no squeezing with *)");
    
    try {
        program.parse_args(argc, argv);
    } catch (const std::exception& err) {
        std::cerr << err.what() << "\n";
        return 1;
    }
    
    std::string subcommand_str = program.present("subcommand") ? program.get<std::string>("subcommand") : "";
    std::string file_str = program.present("file") ? program.get<std::string>("file") : "";
    
    // Detectar si el primer argumento es un subcommand o un archivo
    std::string subcommand;
    std::string filepath;
    
    if (!subcommand_str.empty() && !file_str.empty()) {
        // Caso: akasha_dump <subcommand> <file>
        subcommand = subcommand_str;
        filepath = file_str;
    } else if (!subcommand_str.empty() && file_str.empty()) {
        // Caso: akasha_dump <file> (sin subcommand)
        filepath = subcommand_str;
        subcommand = "default";
    } else {
        std::cerr << "akasha_dump: error: file argument required\n";
        return 1;
    }
    
    std::size_t skip = program.get<std::size_t>("--skip");
    std::size_t length = program.get<std::size_t>("--length");
    bool no_squeezing = program.get<bool>("--no-squeezing");
    
    // Procesar según el subcommand
    if (subcommand == "raw" || subcommand == "a") {
        print_raw_dump(filepath, skip, length, no_squeezing);
    } else if (subcommand == "canonical" || subcommand == "b") {
        print_normal_dump(filepath);
    } else if (subcommand == "default") {
        // Modo normal (sin subcommand)
        print_normal_dump(filepath);
    } else {
        std::cout << "Unknown subcommand: " << subcommand << "\n";
    }
    
    return 0;
}

void print_raw_dump(const std::string& filepath, std::size_t skip, std::size_t length, bool no_squeezing) {
    // Abrir archivo
    std::ifstream file(filepath, std::ios::binary);
    if (!file) {
        std::cerr << "akasha_dump: " << filepath << ": No such file or directory\n";
        return;
    }
    
    // Determinar tamaño del archivo
    file.seekg(0, std::ios::end);
    std::size_t file_size = file.tellg();
    file.seekg(0, std::ios::beg);
    
    // Validar skip
    if (skip >= file_size) {
        return;  // Nada que leer
    }
    
    // Determinar cuántos bytes leer
    std::size_t bytes_to_read;
    if (length == 0) {
        bytes_to_read = file_size - skip;
    } else {
        bytes_to_read = (skip + length <= file_size) ? length : (file_size - skip);
    }
    
    // Leer datos
    file.seekg(skip);
    std::vector<uint8_t> data(bytes_to_read);
    file.read(reinterpret_cast<char*>(data.data()), bytes_to_read);
    
    if (!file && file.gcount() != static_cast<std::streamsize>(bytes_to_read)) {
        std::cerr << "akasha_dump: error reading file\n";
        return;
    }
    
    // Dump con 16 bytes por línea, hex y ASCII
    const std::size_t bytes_per_line = 16;
    std::vector<uint8_t> previous_line;
    bool last_line_was_duplicate = false;
    
    for (std::size_t i = 0; i < data.size(); i += bytes_per_line) {
        std::size_t current_chunk_size = std::min(bytes_per_line, data.size() - i);
        std::vector<uint8_t> current_line(data.begin() + i, data.begin() + i + current_chunk_size);
        
        // Verificar si es idéntica a la anterior
        bool is_duplicate = (!previous_line.empty() && current_line == previous_line);
        
        if (is_duplicate && !no_squeezing) {
            // Mostrar * solo si no lo mostramos ya
            if (!last_line_was_duplicate) {
                printf("*\n");
                last_line_was_duplicate = true;
            }
        } else {
            // Offset en hexadecimal (8 dígitos)
            printf("%08lx  ", static_cast<unsigned long>(skip + i));
            
            // Primera mitad (8 bytes)
            for (std::size_t j = 0; j < 8 && j < current_line.size(); ++j) {
                printf("%02x ", current_line[j]);
            }
            
            // Espaciado entre mitades
            if (current_line.size() > 8) {
                printf(" ");
            } else {
                printf(" ");
                for (std::size_t j = current_line.size(); j < 8; ++j) {
                    printf("   ");
                }
                printf(" ");
            }
            
            // Segunda mitad (8 bytes)
            for (std::size_t j = 8; j < 16 && j < current_line.size(); ++j) {
                printf("%02x ", current_line[j]);
            }
            
            // Relleno para alineación de ASCII
            for (std::size_t j = current_line.size(); j < 16; ++j) {
                printf("   ");
            }
            
            // Separador ASCII
            printf(" |");
            
            // ASCII printable
            for (std::size_t j = 0; j < current_line.size(); ++j) {
                uint8_t c = current_line[j];
                printf("%c", (c >= 32 && c < 127) ? static_cast<char>(c) : '.');
            }
            
            printf("|\n");
            
            last_line_was_duplicate = false;
        }
        
        previous_line = current_line;
    }
    
    // Línea final con tamaño total
    printf("%08lx\n", static_cast<unsigned long>(skip + data.size()));
}

void print_normal_dump(const std::string& filepath) {
    // Placeholder para modo normal (formato estructurado)
    std::cout << "File: " << filepath << "\n";
    std::cout << "Format: Akasha (normal mode - structured view)\n";
    std::cout << "\n[This format is under development]\n";
    std::cout << "Use: akasha_dump <file> raw [options]\n";
    std::cout << "     for hexdump-compatible output.\n";
}

